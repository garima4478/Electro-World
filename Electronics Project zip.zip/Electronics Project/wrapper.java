public class wrapper {
    public static void main(String args[]){
        Integer age=18;
        switch(age){
            case(16):
                System.out.println("under 18");
                break;

            case(18):
                System.out.println("18");
                break;

            case(67):
                System.out.println("senior citizen");
                break;
            default:
                System.out.println("enter valid age");
                break;
        }
    }
}
